# Within Your Power — Auditoría editorial bilingüe y de coherencia

**Fecha:** 17 de noviembre de 2026  
**Fuente:** `Within-Your-Power-COMPLETO (1).zip`, archivos de `4-capitulos-fuente/`, hoja de estilo y protocolo de evaluación.  
**Alcance:** inspección del texto de los trece capítulos, revisión dirigida de continuidad y recuentos automáticos de patrones; no es un dictamen humano de un editor nativo ni una verificación externa de fuentes históricas.  
**Importante:** no se ha modificado el manuscrito. El prólogo se conserva intacto.

## Veredicto ejecutivo

**El inglés es mayoritariamente idiomático y legible para Estados Unidos; la prioridad no es retraducirlo, sino una edición de ritmo y continuidad, seguida de comprobación de fuentes.** La calidad no puede reducirse a un único puntaje objetivo. Las notas siguientes son juicios editoriales orientativos y no sustituyen la revisión humana de un *native line editor*.

## Calificaciones orientativas del conjunto

| Criterio del protocolo | Nota /10 | Justificación |
|---|---:|---|
| Native fluency | 8.5 | Registro conversacional generalmente natural; algunas simplificaciones y frases de efecto suenan prefabricadas, más que traducidas. |
| Voice and rhythm | 7.0 | Aperturas vivas y escenas accesibles; la arquitectura y los remates repetidos reducen la variación. |
| AI-generated tells (10 = pocos patrones) | 6.0 | Contrastes retóricos y moralejas compactas recurrentes; no prueban autoría por IA. |
| Cultural fit (EE. UU.) | 8.0 | Localización consistente en líneas generales; hay que comprobar cronología, instituciones y montos con la hoja de estilo. |
| Clarity and concision | 7.5 | Ideas comprensibles, pero varias explicaciones y conclusiones reiteran una misma tesis. |
| Credibility | 7.0 | Las paráfrasis están etiquetadas; conviene verificar atribuciones y matizar vínculos entre estoicismo y psicoterapia. |
| Commercial readiness | 7.0 | Base publicable tras una pasada editorial seria y QA de hechos, continuidad y referencias. |
| **Media orientativa** | **7.3** | **No es un certificado de publicación ni una evaluación ciega.** |

## Recuento reproducible de patrones por capítulo

Conteos de búsqueda textual **aproximados**, no equivalentes a oraciones defectuosas. `not … but` busca ambos términos a un máximo de 65 caracteres; `isn't … it's` busca la secuencia con un máximo de 70 caracteres; ambas expresiones pueden coincidir en un mismo pasaje y también capturar diálogos o citas. Se omiten introducción, prólogo y anexos de esta tabla.

| Capítulo | Palabras aprox. | `not … but` | `isn't … it's` | `In a nutshell` |
|---|---:|---:|---:|---:|
| 1 | 3,944 | 4 | 8 | 2 |
| 2 | 3,038 | 3 | 3 | 1 |
| 3 | 2,901 | 1 | 5 | 2 |
| 4 | 2,655 | 5 | 0 | 1 |
| 5 | 2,602 | 1 | 2 | 2 |
| 6 | 2,831 | 1 | 2 | 1 |
| 7 | 2,866 | 1 | 4 | 2 |
| 8 | 2,715 | 4 | 6 | 1 |
| 9 | 2,565 | 3 | 1 | 2 |
| 10 | 2,676 | 2 | 0 | 1 |
| 11 | 2,709 | 2 | 2 | 2 |
| 12 | 2,578 | 5 | 3 | 1 |
| 13 | 2,981 | 4 | 5 | 2 |
| **Total** | **37,061** | **36** | **41** | **20** |

## Problemas prioritarios, con citas textuales y propuestas

### 1. Coherencia financiera de Lauren y Andrew (capítulos 8 y 11)

**Original, capítulo 8:** “When Lauren left her job for a year to stay home with their newborn son, Andrew became the only one earning a paycheck.”  
**Original, capítulo 8:** “Since her promotion, Lauren has been out-earning Andrew.”  
**Original, capítulo 11:** “Lauren and Andrew have always kept their finances separate: each paid their own expenses, and they split household bills down the middle.”

**Diagnóstico:** el *always* del capítulo 11 suena absoluto después de la etapa de un único ingreso y del acuerdo posterior de tratar ambos salarios como dinero del hogar. Puede haber una evolución legítima, pero falta marcarla.

**Corrección sugerida (cap. 11, sujeta a confirmar cronología):** “For most of their marriage, Lauren and Andrew had managed their money separately, splitting household bills down the middle.” Si el capítulo 11 ocurre **después** del acuerdo del capítulo 8, habrá que reescribir el escenario, no solo una frase.

### 2. Relación entre hechos externos y decisiones propias (capítulo 1)

**Original:** “The only thing you control in that moment is what you do with all of it on the inside.”  
**Problema:** *only* y *on the inside* reducen indebidamente la agencia a la reacción mental, aunque el libro después incluye acciones deliberadas.  
**Propuesta:** “You can't make the traffic move, but you can choose how to respond—and what to do next.”

### 3. Afirmación excesiva sobre emoción y cognición (capítulo 1)

**Original:** “The core idea is nearly identical: events don't upset us; our beliefs about events do.”  
**Problema:** presenta la relación entre terapia cognitiva y estoicismo como casi idéntica, sin distinguir modelos clínicos y tradición filosófica.  
**Propuesta:** “One important point of overlap is that our interpretations can shape how we feel about what happens.”

### 4. Posible responsabilización excesiva de quien sufre (capítulo 1)

**Original:** “It means there's a gap between the blow and the wound, and that gap belongs to you.”  
**Problema:** la metáfora es potente, pero sugiere que la lesión causada por otros siempre depende de la víctima. El capítulo contiene una salvaguarda sobre abuso, que debe preservarse.  
**Propuesta:** “It means that, even when the blow is real, how we interpret it can shape what happens next.”

### 5. Remate demasiado limpio de la adversidad (capítulo 4)

**Original:** “Not because crises are good, but because they force you to do what comfort let you put off.”  
**Problema:** generalización causal; algunas crisis incapacitan y no generan crecimiento.  
**Propuesta:** “A crisis can sometimes push us toward decisions we've postponed—but that doesn't make the crisis itself good.”

### 6. Simplificación psicológica en salud (capítulo 1)

**Original:** “Six months later, her blood sugar is back in the normal range. Not because philosophy cures anything, but because she stopped spending her energy in the wrong column.”  
**Problema:** el texto sí niega una cura filosófica, pero la frase final minimiza el papel de atención médica y cambios de hábitos.  
**Propuesta:** “Six months later, her blood sugar is back in the normal range. The philosophy didn't treat her condition; it helped her follow through on her doctor's advice.”

### 7. Cierre de arco de pareja excesivamente conclusivo (capítulo 4)

**Original:** “But the obstacle became the road to an honest conversation, and that's worth something however it ends.”  
**Problema:** la metáfora cierra demasiado pronto una situación de incertidumbre afectiva.  
**Propuesta:** “They still don't know what will happen to their marriage. For now, at least, they're talking honestly.”

### 8. Un final de escena predecible (capítulo 11)

**Original:** “Nothing bad happens. The hive gets a little bigger.”  
**Problema:** cierre con moraleja y resolución demasiado fácil del rechazo social infantil.  
**Propuesta:** “Sophie is nervous when she asks. The new girl says yes, and they sit together at lunch.”

### 9. Formulación demasiado absoluta (capítulo 10)

**Original:** “Not because things will go well, but because you'll be there, with your reason intact.”  
**Problema:** la razón no permanece necesariamente intacta bajo enfermedad o deterioro cognitivo; la frase promete demasiado.  
**Propuesta:** “Not because things are guaranteed to go well, but because you can prepare to meet uncertainty as thoughtfully as possible.”

### 10. Una conclusión que suena a aforismo prefabricado (capítulo 13)

**Original:** “Remembering death isn't loving death; it's learning to love life before it's over.”  
**Problema:** eficaz aisladamente, pero se suma a muchas estructuras de contraste con remate perfecto.  
**Propuesta:** “Remembering that life ends can change how closely we pay attention to the time we have.”

## Revisión por capítulo: prioridades

| Capítulo | Foco de edición | Riesgo |
|---|---|---|
| 1 | Dicotomía del control, psicología y consecuencias de las acciones; preservar advertencia sobre abuso | Alto |
| 2 | Evitar generalizar el comportamiento ajeno; precisión sobre *mental contrasting* | Medio |
| 3 | Distinguir disciplina de obediencia; reducir sentencias simétricas | Medio |
| 4 | Línea temporal de despido de Rick y terapia de Lauren/Andrew; evitar convertir todo revés en oportunidad | Alto |
| 5 | Revisar imágenes retóricas y si sus explicaciones se repiten | Medio |
| 6 | Matizar obligaciones de bondad frente a límites personales | Medio |
| 7 | Consistencia entre prestigio, belleza y valor moral | Medio |
| 8 | Dos etapas de ingresos de Lauren/Andrew; promoción de Rick y su nuevo trabajo | Alto |
| 9 | Reducir reiteraciones de *necessary/unnecessary* y verificar que simplificar no implique descuidar deberes | Medio |
| 10 | Evitar garantías sobre resiliencia; distinguir preparación y preocupación | Medio |
| 11 | Contradicción potencial de finanzas separadas; realismo de resolución en escenas | Alto |
| 12 | Conservar especificidad de la gratitud; evitar remates idénticos | Medio |
| 13 | Sensibilidad sobre muerte, crisis y salud mental; moderar aforismos | Alto |

## Coherencia de personajes: control editorial

- **Lauren y Andrew:** la hoja de estilo establece diez años juntos, un hijo y terapia desde el capítulo 4. Revisar la secuencia: crianza con un solo sueldo → promoción de Lauren → acuerdo financiero → escena de finanzas separadas del capítulo 11.
- **Rick:** once años en la empresa; despido a los cuarenta y cuatro (cap. 4); liderazgo de seis personas en un nuevo empleo (cap. 8). La progresión es posible; se debe explicitar el lapso.
- **Megan:** estudio de diseño, cliente que no paga, caída de ingresos, crecimiento y contratación; comprobar que la evolución económica sea plausible y que los hitos estén ordenados.
- **George:** MBA de fin de semana a los treinta y ocho, repite estadística y se gradúa a los treinta y nueve; revisar la duración que implica el semestre adicional.
- **Claire y Sophie:** Sophie tiene diez años según la hoja de estilo; verificar que edad y nivel escolar se mantengan.

## Diagnóstico de naturalidad del inglés

La mayoría de las expresiones examinadas son idiomáticas: “spends the weekend stewing”, “sinks into a funk”, “called him on it”, “the floor drop out from under her”, “land on a solution”. **No deben cambiarse por el simple hecho de ser coloquiales.** El principal problema es la *uniformidad editorial*, no una sintaxis típicamente traducida. La detección de rasgos de IA es un análisis de estilo, no una prueba de origen.

## Comprobaciones pendientes antes de publicar

1. Contrastar las referencias a *Meditations*, *Enchiridion*, Séneca y Cicerón con traducciones y pasajes verificables. La etiqueta *paraphrase* es útil, pero no sustituye la verificación.
2. Comprobar por separado afirmaciones históricas y de investigación psicológica, especialmente las cifras epidemiológicas, relaciones causales y estudios citados.
3. Confirmar vigencia de teléfonos de crisis y violencia doméstica antes de impresión.
4. Hacer lectura en voz alta por un editor humano estadounidense y revisión completa oración por oración. Este informe incluye **diez intervenciones prioritarias**, no una enumeración exhaustiva de cada oración ligeramente extraña.
5. Realizar una segunda pasada después de aplicar correcciones para asegurar que la voz y la cronología sigan consistentes.

## Decisión

**Recomiendo edición focalizada, no reescritura total.** Congelar el prólogo por instrucción del paquete, resolver primero la continuidad de Lauren/Andrew, después matizar los pasajes con posibles lecturas de culpa o falsas garantías, y finalmente variar la cadencia de las conclusiones. No publicar todavía sin comprobación de referencias y prueba editorial final.
